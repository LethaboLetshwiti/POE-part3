document.addEventListener('DOMContentLoaded', () => {
    
    // ==========================================
    // 1. FORM VALIDATION & ERROR HANDLING (Contact & Enquiry)
    // ==========================================
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        // We attach an event listener to the submit button (the requirement)
        form.addEventListener('submit', function(e) {
            e.preventDefault(); // Stop normal submission for client-side validation
            
            let isValid = true;
            let errorMessages = [];

            // Clear previous errors
            form.querySelectorAll('.error-msg').forEach(el => el.remove());
            form.querySelectorAll('.error-input').forEach(el => el.classList.remove('error-input'));

            // --- CONTACT PAGE SPECIFIC VALIDATION ---
            if (form.querySelector('#contact-name')) {
                const name = document.getElementById('contact-name');
                const email = document.getElementById('contact-email');
                const subject = document.getElementById('contact-subject');
                const message = document.getElementById('contact-message');

                // Validate Name (min 3 chars)
                if (name.value.trim().length < 3) {
                    isValid = false;
                    showError(name, 'Please enter a valid full name (at least 3 characters).');
                }

                // Validate Email (Regex format)
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email.value.trim())) {
                    isValid = false;
                    showError(email, 'Please enter a valid email address.');
                }

                // Validate Subject
                if (subject.value.trim() === '') {
                    isValid = false;
                    showError(subject, 'Please enter a subject.');
                }

                // Validate Message (min 10 chars)
                if (message.value.trim().length < 10) {
                    isValid = false;
                    showError(message, 'Message must be at least 10 characters long.');
                }

                // If valid, COMPILE INTO AN EMAIL (Requirement from images)
                if (isValid) {
                    const recipient = "info@mysolholdingsandlogistics.com";
                    const emailSubject = encodeURIComponent(`Website Contact: ${subject.value}`);
                    const emailBody = encodeURIComponent(
                        `Name: ${name.value}\nEmail: ${email.value}\n\nMessage:\n${message.value}`
                    );
                    
                    // Opens the user's default email client with the compiled info
                    window.location.href = `mailto:${recipient}?subject=${emailSubject}&body=${emailBody}`;
                    
                    // Show success feedback
                    form.innerHTML = `<div style="text-align:center; padding: 2rem; color: var(--blue);">
                        <h3>Thank you!</h3>
                        <p>Your email client should now open to send the message.</p>
                    </div>`;
                }
            }

            // --- ENQUIRY PAGE SPECIFIC VALIDATION ---
            if (form.querySelector('#fullname')) {
                const fullname = document.getElementById('fullname');
                const email = document.getElementById('email');
                const phone = document.getElementById('phone');
                const message = document.getElementById('message');

                // Validate Full Name
                if (fullname.value.trim().length < 3) {
                    isValid = false;
                    showError(fullname, 'Full name is required.');
                }

                // Validate Email
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email.value.trim())) {
                    isValid = false;
                    showError(email, 'A valid email address is required.');
                }

                // Validate Phone (Optional, but check format if entered - allows numbers, spaces, +)
                const phoneRegex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
                if (phone.value.trim() !== '' && !phoneRegex.test(phone.value.trim())) {
                    isValid = false;
                    showError(phone, 'Please enter a valid phone number format.');
                }

                // Validate Message
                if (message.value.trim().length < 5) {
                    isValid = false;
                    showError(message, 'Please provide more details in your message.');
                }

                // If valid, Process Response (Mock response)
                if (isValid) {
                    const enquiryType = document.getElementById('enquiry-type').value;
                    const serviceType = document.getElementById('service-interest').value;
                    
                    form.innerHTML = `<div style="text-align:center; padding: 2rem; background: var(--off-white); border-radius: var(--radius);">
                        <h3 style="color: var(--orange);">Enquiry Received!</h3>
                        <p>Thank you, ${fullname.value}. We have received your enquiry regarding <strong>${serviceType}</strong>.</p>
                        <p><em>Our team will contact you shortly with information on cost and availability.</em></p>
                    </div>`;
                }
            }
        });
    });

    // Helper function to show error messages
    function showError(inputElement, message) {
        inputElement.classList.add('error-input');
        
        // Check if error message already exists
        let errorNode = inputElement.nextElementSibling;
        if (!errorNode || !errorNode.classList.contains('error-msg')) {
            errorNode = document.createElement('div');
            errorNode.className = 'error-msg';
            inputElement.parentNode.insertBefore(errorNode, inputElement.nextSibling);
        }
        errorNode.textContent = message;
        errorNode.style.color = '#dc3545';
        errorNode.style.fontSize = '0.85rem';
        errorNode.style.marginTop = '5px';
        errorNode.style.fontWeight = '600';
    }

    // ==========================================
    // 2. DYNAMIC CONTENT: SEARCH & FILTER (Services Page)
    // ==========================================
    const servicesMain = document.querySelector('main');
    const serviceSections = document.querySelectorAll('main > section:nth-of-type(2), main > section:nth-of-type(3), main > section:nth-of-type(4)');
    
    // Only run if we are on the services page (checking if first service title exists)
    if (servicesMain && serviceSections.length > 0 && serviceSections[0].innerHTML.includes('Plant Hire')) {
        // Inject a search bar dynamically
        const searchContainer = document.createElement('div');
        searchContainer.style.marginBottom = '2rem';
        searchContainer.style.textAlign = 'center';
        searchContainer.innerHTML = `
            <input type="text" id="serviceSearch" placeholder="Search our services..." 
                   style="padding: 12px 20px; width: 100%; max-width: 500px; border-radius: 50px; border: 2px solid #e9ecef; outline: none; font-size: 1rem;">
            <p id="noResults" style="display:none; color: #e8751a; font-weight: bold; margin-top: 1rem;">No services found matching your search.</p>
        `;
        servicesMain.insertBefore(searchContainer, serviceSections[0]);

        const searchInput = document.getElementById('serviceSearch');
        const noResults = document.getElementById('noResults');

        searchInput.addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase();
            let hasResults = false;

            serviceSections.forEach(section => {
                const text = section.textContent.toLowerCase();
                if (text.includes(term)) {
                    section.style.display = 'inline-block';
                    hasResults = true;
                } else {
                    section.style.display = 'none';
                }
            });

            noResults.style.display = hasResults ? 'none' : 'block';
        });
    }

    // ==========================================
    // 3. INTERACTIVE ELEMENTS (Accordion - About Page)
    // ==========================================
    // Dynamically make "Team Cards" collapsible on click (Accordion requirement)
    const teamCards = document.querySelectorAll('.team-card');
    if (teamCards.length > 0) {
        teamCards.forEach(card => {
            const info = card.querySelector('.team-info p:last-child');
            if (info) {
                info.style.display = 'none'; // Hide by default
                card.style.cursor = 'pointer';
                
                card.addEventListener('click', () => {
                    const isHidden = info.style.display === 'none';
                    info.style.display = isHidden ? 'block' : 'none';
                    // Add a subtle transition
                    info.style.animation = isHidden ? 'fadeIn 0.3s ease' : 'none';
                });
            }
        });
    }

    // ==========================================
    // 4. LIGHTBOX FOR IMAGES (About Page / Gallery)
    // ==========================================
    const teamImages = document.querySelectorAll('.team-photo img');
    if (teamImages.length > 0) {
        // Create Lightbox HTML dynamically
        const lightbox = document.createElement('div');
        lightbox.id = 'lightbox';
        lightbox.innerHTML = `
            <span id="closeLightbox" style="position:absolute; top:20px; right:40px; font-size:3rem; color:white; cursor:pointer;">&times;</span>
            <img id="lightboxImg" style="max-height: 85vh; max-width: 90vw; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
        `;
        // Basic styling for the lightbox overlay
        lightbox.style.cssText = `
            display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(10, 61, 107, 0.9); z-index: 9999; justify-content: center; align-items: center;
        `;
        document.body.appendChild(lightbox);

        const lightboxImg = document.getElementById('lightboxImg');
        const closeBtn = document.getElementById('closeLightbox');

        teamImages.forEach(img => {
            img.style.cursor = 'pointer';
            img.addEventListener('click', (e) => {
                lightbox.style.display = 'flex';
                lightboxImg.src = e.target.src;
            });
        });

        closeBtn.addEventListener('click', () => {
            lightbox.style.display = 'none';
        });
        
        // Close on background click
        lightbox.addEventListener('click', (e) => {
            if (e.target === lightbox) lightbox.style.display = 'none';
        });
    }

    // ==========================================
    // 5. INTERACTIVE MAPS (Contact Page Modal)
    // ==========================================
    const iframes = document.querySelectorAll('main iframe');
    if (iframes.length > 0) {
        iframes.forEach(iframe => {
            // Hide iframe initially
            iframe.style.display = 'none';
            
            // Create a "View Map" button
            const btn = document.createElement('button');
            btn.textContent = "View Interactive Map";
            btn.style.cssText = "padding: 10px 20px; background: var(--blue); color: white; border: none; border-radius: 5px; cursor: pointer; margin-top: 15px; font-weight: bold;";
            iframe.parentNode.insertBefore(btn, iframe);

            // Create Map Modal
            const mapModal = document.createElement('div');
            mapModal.style.cssText = `display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 10000; justify-content: center; align-items: center; flex-direction: column;`;
            mapModal.innerHTML = `<div style="background: white; padding: 10px; border-radius: 8px; width: 90%; max-width: 800px; height: 70vh; position: relative;">
                                    <span style="position:absolute; top:-35px; right:0; color:white; font-size:2rem; cursor:pointer;" class="close-map">&times;</span>
                                    <iframe src="${iframe.src}" style="width:100%; height:100%; border:none; border-radius: 5px;"></iframe>
                                  </div>`;
            document.body.appendChild(mapModal);

            // Open modal
            btn.addEventListener('click', () => {
                mapModal.style.display = 'flex';
            });

            // Close modal
            mapModal.querySelector('.close-map').addEventListener('click', () => {
                mapModal.style.display = 'none';
            });
        });
    }
});

// Simple keyframe animation injection for the accordion
const styleSheet = document.createElement("style");
styleSheet.textContent = `@keyframes fadeIn { from { opacity: 0; transform: translateY(-5px); } to { opacity: 1; transform: translateY(0); } }`;
document.head.appendChild(styleSheet);